# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> Khi temperature tăng từ 0.0 lên 1.5, câu trả lời thường chuyển từ ổn định, an toàn sang đa dạng và "sáng tạo" hơn. Ở mức thấp (0.0-0.5), nội dung nhất quán và ít biến động giữa các lần chạy; ở mức cao (1.0-1.5), cách diễn đạt phong phú hơn nhưng cũng dễ lan man hoặc kém chính xác hơn.  


**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> Mình sẽ đặt khoảng **0.2-0.4** (ví dụ 0.3) để ưu tiên tính nhất quán, rõ ràng và giảm rủi ro "bịa" thông tin. Đây là mức cân bằng tốt giữa tự nhiên khi trả lời và độ tin cậy trong bối cảnh hỗ trợ khách hàng.  

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
> Tổng số lượt gọi/ngày = 10,000 x 3 = **30,000 calls**. Tổng token output/ngày = 30,000 x 350 = **10,500,000 tokens**.  
> - GPT-4o: (10,500,000 / 1,000) x 0.010 = **$105/ngày**  
> - GPT-4o-mini: (10,500,000 / 1,000) x 0.0006 = **$6.3/ngày**  
> Tỉ lệ chi phí: 105 / 6.3 ≈ **16.7 lần**.  

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
> GPT-4o đáng tiền trong các tác vụ rủi ro cao như tư vấn chuyên môn nội bộ, xử lý câu hỏi phức tạp nhiều bước, hoặc nơi chất lượng lập luận ảnh hưởng trực tiếp đến quyết định kinh doanh.  
> GPT-4o-mini phù hợp hơn cho FAQ lặp lại, phân loại yêu cầu, tóm tắt ngắn, hoặc chatbot khối lượng lớn cần tối ưu chi phí và độ trễ.  


---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** 
> Streaming quan trọng nhất khi phản hồi dài hoặc người dùng cần cảm giác "đang được phục vụ ngay" (ví dụ trợ lý chat, hỗ trợ trực tiếp, viết nội dung), vì token đầu tiên đến sớm giúp giảm cảm nhận chờ đợi và tăng trải nghiệm. Ngược lại, non-streaming phù hợp khi cần toàn bộ kết quả hoàn chỉnh trước khi hiển thị hoặc xử lý tiếp (ví dụ kiểm duyệt đầu ra, parse JSON nghiêm ngặt, pipeline tự động), vì dễ kiểm soát định dạng và logic hậu xử lý hơn.  



## Danh Sách Kiểm Tra Nộp Bài
- [ ] Tất cả tests pass: `pytest tests/ -v`
- [ ] `call_openai` đã triển khai và kiểm thử
- [ ] `call_openai_mini` đã triển khai và kiểm thử
- [ ] `compare_models` đã triển khai và kiểm thử
- [ ] `streaming_chatbot` đã triển khai và kiểm thử
- [ ] `retry_with_backoff` đã triển khai và kiểm thử
- [ ] `batch_compare` đã triển khai và kiểm thử
- [ ] `format_comparison_table` đã triển khai và kiểm thử
- [ ] `exercises.md` đã điền đầy đủ
- [ ] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 

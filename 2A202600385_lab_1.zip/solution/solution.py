import os
import time
from typing import Any, Callable
from openai import OpenAI

COST_PER_1K_OUTPUT_TOKENS = {
    "gpt-4o": 0.010,
    "gpt-4o-mini": 0.0006,
}

OPENAI_MODEL = "gpt-4o"
OPENAI_MINI_MODEL = "gpt-4o-mini"

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# =========================
# Task 1
# =========================
def call_openai(
    prompt: str,
    model: str = OPENAI_MODEL,
    temperature: float = 0.7,
    top_p: float = 0.9,
    max_tokens: int = 256,
) -> tuple[str, float]:

    start_time = time.time()

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
        )
        response_text = response.choices[0].message.content

    except Exception as e:
        response_text = f"Error: {str(e)}"

    end_time = time.time()
    latency = end_time - start_time

    return response_text, latency


# =========================
# Task 2
# =========================
def call_openai_mini(
    prompt: str,
    temperature: float = 0.7,
    top_p: float = 0.9,
    max_tokens: int = 256,
) -> tuple[str, float]:

    return call_openai(
        prompt,
        model=OPENAI_MINI_MODEL,
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens,
    )


# =========================
# Task 3
# =========================
def compare_models(prompt: str) -> dict:

    gpt4o_response, gpt4o_latency = call_openai(prompt)
    mini_response, mini_latency = call_openai_mini(prompt)

    gpt4o_tokens_est = len(gpt4o_response.split()) / 0.75
    gpt4o_cost = (gpt4o_tokens_est / 1000) * COST_PER_1K_OUTPUT_TOKENS["gpt-4o"]

    return {
        "gpt4o_response": gpt4o_response,
        "mini_response": mini_response,
        "gpt4o_latency": gpt4o_latency,
        "mini_latency": mini_latency,
        "gpt4o_cost_estimate": gpt4o_cost,
    }


# =========================
# Task 4
# =========================
def streaming_chatbot() -> None:

    history = []

    while True:
        user_input = input("\nYou: ")

        if user_input.lower() in ["quit", "exit"]:
            print("Goodbye!")
            break

        history.append({"role": "user", "content": user_input})

        print("Assistant: ", end="", flush=True)

        stream = client.chat.completions.create(
            model=OPENAI_MINI_MODEL,
            messages=history,
            stream=True,
        )

        full_reply = ""

        for chunk in stream:
            delta = chunk.choices[0].delta.content or ""
            print(delta, end="", flush=True)
            full_reply += delta

        print()

        history.append({"role": "assistant", "content": full_reply})

        # giữ 3 turns = 6 messages
        history = history[-6:]


# =========================
# Bonus A
# =========================
def retry_with_backoff(
    fn: Callable,
    max_retries: int = 3,
    base_delay: float = 0.1,
) -> Any:

    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as e:
            if attempt == max_retries:
                raise e
            time.sleep(base_delay * (2 ** attempt))


# =========================
# Bonus B
# =========================
def batch_compare(prompts: list[str]) -> list[dict]:

    results = []
    for p in prompts:
        r = compare_models(p)
        r["prompt"] = p
        results.append(r)

    return results


# =========================
# Bonus C
# =========================
def format_comparison_table(results: list[dict]) -> str:

    def truncate(text, n=40):
        return text if len(text) <= n else text[:37] + "..."

    header = f"{'Prompt':<40} | {'GPT-4o':<40} | {'Mini':<40}"
    rows = [header, "-" * len(header)]

    for r in results:
        rows.append(
            f"{truncate(r['prompt']):<40} | "
            f"{truncate(r['gpt4o_response']):<40} | "
            f"{truncate(r['mini_response']):<40}"
        )

    return "\n".join(rows)


# =========================
# MAIN TEST
# =========================
if __name__ == "__main__":
    print(compare_models("Explain AI in one sentence"))
    streaming_chatbot()
    retry_with_backoff()
    batch_compare()
    format_comparison_table()